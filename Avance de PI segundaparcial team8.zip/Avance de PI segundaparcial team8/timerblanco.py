import pygame
pygame.init()
screen = pygame.display.set_mode((1024, 720))
clock = pygame.time.Clock()

counter, text = 10, '10'.rjust(3)
pygame.time.set_timer(pygame.USEREVENT, 1000)
font = pygame.font.SysFont('Consolas', 30)

run = True
while run:
    for e in pygame.event.get():
        if e.type == pygame.USEREVENT: 
            counter -= 1
            text = str(counter).rjust(3) if counter > 0 else 'boom!'
        if e.type == pygame.QUIT: 
            run = False

    
    screen.blit(font.render(text, True, (255, 0, 0)), (32, 48))
    pygame.display.flip()
    clock.tick(60)