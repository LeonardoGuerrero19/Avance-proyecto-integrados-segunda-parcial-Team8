import pygame, random
#Variables a necesitar
ancho = 800
altura = 600
negro = (0,0,0) #color negro
blanco = (255,255,255) #Color blanco

pygame.init() # Inicia la libreria pygame
#-------Sonidos-------------
pygame.mixer.init() #Inicia la libreria de sonidos de pygame
#salto = pygame.mixer.Sound("EfectosDeSonido/salto1.wav") #Se declara para despues ponerla en la funcion de saltar.
#past = pygame.mixer.Sound("EfectosDeSonido/pastocaminar.mp3")#Se declara el sonido al moverse para despues llamar la funcion.
#pygame.mixer.music.load("Otra musica.mp3")#Se introduce la musica, se activa la musica y se modifica el volumen que queremos.
#pygame.mixer.music.play(2)
#pygame.mixer.music.set_volume(0.7)

pantalla = pygame.display.set_mode((ancho, altura))
pygame.display.set_caption("Dark Sky")
clock = pygame.time.Clock()

class Jugador(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("player.png").convert()
        self.image.set_colorkey(negro)
        self.rect = self.image.get_rect()
        self.rect.centerx = ancho // 2
        self.rect.centery = altura - 10
        self.speed_x = 0
    
   # def update(self):
        #self.speed_x = 0
        #keystate = pygame.key.get_pressed()
        #if keystate

fondo = pygame.image.load("fondoverde.png").convert()
all_sprites = pygame.sprite.Group()

jugador = Jugador()
all_sprites.add(jugador)

bucle = True
while bucle:
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            bucle = False

    all_sprites.update()
    
    pantalla.blit(fondo, [0, 0] )

    all_sprites.draw(pantalla)

    pygame.display.flip()
    pygame.quit()